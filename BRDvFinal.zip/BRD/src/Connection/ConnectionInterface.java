package Connection;
import java.sql.Connection;
public interface ConnectionInterface {
	public Connection myConnection();

}
