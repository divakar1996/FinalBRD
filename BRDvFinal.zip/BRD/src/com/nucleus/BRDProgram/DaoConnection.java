package com.nucleus.BRDProgram;

import Connection.ConnectionInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Connection.OracleConnection;

public class DaoConnection {

	Connection conn = null;
	ConnectionInterface cx = null;
	PreparedStatement stmp = null;
	//INSERTING DATA INTO THE DATA BASE IN WHICH THE PARAMETER IS CUSTOMER MASTER TABLE TYPE
	public void insertion(CustomerMasterTable cmt) {

		int count = 0;

		try {
			cx = new OracleConnection();
			conn = cx.myConnection();

			stmp = conn
					.prepareStatement("insert into ROYCUSTOMERTABLE values(royid.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			stmp.setString(1, cmt.getCustomerCode());
			stmp.setString(2, cmt.getCustomerName());
			stmp.setString(3, cmt.getCustomerAddress1());
			stmp.setString(4, cmt.getCustomerAddress2());
			stmp.setString(5, cmt.getCustomerPinCode());
			stmp.setString(6, cmt.getEmailAddress());
			stmp.setString(7, cmt.getContactNumber());
			stmp.setString(8, cmt.getPrimaryContactPerson());
			stmp.setString(9, cmt.getRecordStatus());
			stmp.setString(10, cmt.getActiveInactiveFlag());
			stmp.setString(11, cmt.getCreateDate());
			stmp.setString(12, cmt.getCreatedBy());
			stmp.setString(13, cmt.getModifiedDate());
			stmp.setString(14, cmt.getModifiedBy());
			stmp.setString(15, cmt.getAuthorizedDate());
			stmp.setString(16, cmt.getAuthorizedBy());
			count = stmp.executeUpdate();
			if (count > 0) {
				System.out.println("Record Inserted");
			} else
				System.out.println("NOT INSERTED");

		} catch (SQLException ex) {
			ex.printStackTrace();

		} finally {
			try {
				conn.commit();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

	}
	//THIS METHOD IS FOR THE ROLLBACK DATA FROM DATA BASE IN F MODE
	//NOT WORKING******************
/*	public void rollBack() throws SQLException{
		
		PreparedStatement stmp=conn.prepareStatement("delete from ROYCUSTOMERTABLE");
		int count=stmp.executeUpdate();
		if(count>0)
			System.out.println("Record Deleted");
		
		try {
			conn.commit();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
	}
	public void deleteTableElement(){
		try {
			cx = new OracleConnection();
			conn = cx.myConnection();

			stmp = conn
					.prepareStatement("delete from ROYCUSTOMERTABLE");

		}catch(SQLException e){
			e.printStackTrace();
			
		}
	}*/

}
