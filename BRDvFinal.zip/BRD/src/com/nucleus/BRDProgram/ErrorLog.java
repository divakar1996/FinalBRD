package com.nucleus.BRDProgram;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ErrorLog {

	
	public void saveToFile1(String line) throws IOException {
		BufferedWriter br = new BufferedWriter(new FileWriter(
				"D:/BRD-File Upload/Rollbacked Record.txt", true));
		br.write(line);
		br.flush();
		br.newLine();
		br.close();

	}
	public void saveToFile2(String line) throws IOException {
		BufferedWriter br = new BufferedWriter(new FileWriter(
				"D:/BRD-File Upload/errorlog1.txt", true));
		br.write(line);
		br.flush();
		br.newLine();
		br.close();

	}
}
