package com.nucleus.BRDProgram;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
//import java.io.ObjectInputStream.GetField;
//import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Tester {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		BufferedReader bufferedReader = null;
		BufferedWriter bufferedWriter1 = null;
		BufferedWriter bufferedReader2 = null;
		String line = null;
		int flag = 0;
		DaoConnection daoConnection = new DaoConnection();
		// DaoConnection daoConnection=null;
		List<String> list = new ArrayList<String>();
		CustomerMasterTable customerMasterTable = new CustomerMasterTable();

		Validation validation = new Validation();
		// ErrorLog errorLog = new ErrorLog();
		RollBakedRecordClass rollBack = new RollBakedRecordClass();
		boolean v1 = false;
		boolean v2 = false;
		boolean v3 = false;
		boolean v4 = false;
		boolean v5 = false;
		boolean v6 = false;
		boolean v7 = false;
		boolean v8 = false;
		boolean v9 = false;
		boolean v10 = false;
		boolean v11 = false;
		boolean v12 = false;
		boolean v13 = false;
		boolean v14 = false;
		//boolean v15=false;

		boolean fileFormat = false;

		try {
			bufferedWriter1 = new BufferedWriter(new FileWriter(
					"D:/BRD-File Upload/errorlogrecord.txt", true));
		} catch (IOException e1) {

			e1.printStackTrace();
		}

		try {
			bufferedReader2 = new BufferedWriter(new FileWriter(
					"D:/BRD-File Upload/errorlog1.txt", true));
		} catch (IOException e1) {

			e1.printStackTrace();
		}

		int n;

		String fileLocation = "D:\\BRD-File Upload\\Test Cases\\";
		System.out.println("Enter file name");
		String fileName = scanner.nextLine();
		fileFormat = validation.fileFormat(fileName);

		if (fileFormat) {

			try {
				bufferedReader = new BufferedReader(new FileReader(fileLocation
						+ fileName));

				System.out.println("File Loaded Successfully..............");

				System.out.println("CHOICE*******");
				System.out
						.println("1. R For record level Rejection\n2.F for File level Rejection");
				n = scanner.nextInt();
				// split and tokenze the file line by line
				try {
					while ((line = bufferedReader.readLine()) != null) {
						String[] token = line.split("~", -1);

						customerMasterTable.setCustomerCode(token[0]);
						customerMasterTable.setCustomerName(token[1]);
						customerMasterTable.setCustomerAddress1(token[2]);
						customerMasterTable.setCustomerAddress2(token[3]);
						customerMasterTable.setCustomerPinCode(token[4]);
						customerMasterTable.setEmailAddress(token[5]);
						customerMasterTable.setContactNumber(token[6]);
						customerMasterTable.setPrimaryContactPerson(token[7]);
						customerMasterTable.setRecordStatus(token[8]);
						customerMasterTable.setActiveInactiveFlag(token[9]);
						customerMasterTable.setCreateDate(token[10]);
						customerMasterTable.setCreatedBy(token[11]);
						customerMasterTable.setModifiedDate(token[12]);
						customerMasterTable.setModifiedBy(token[13]);
						customerMasterTable.setAuthorizedDate(token[14]);
						customerMasterTable.setAuthorizedBy(token[15]);

						// *********************************Validation******************************************

						v1 = validation
								.customerCodeValidation(customerMasterTable
										.getCustomerCode());

						v2 = validation
								.customerNameValidation(customerMasterTable
										.getCustomerName());

						v3 = validation.validationAddress1(customerMasterTable
								.getCustomerAddress1());

						v4 = validation.validationAddress2(customerMasterTable
								.getCustomerAddress2());

						v5 = validation.pinCodeValidation(customerMasterTable
								.getCustomerPinCode());

						v6 = validation.isValidEmailCheck(customerMasterTable
								.getEmailAddress());
						v7 = validation
								.contactNumberValidation(customerMasterTable
										.getContactNumber());

						v8 = validation
								.primaryContactPersonValidation(customerMasterTable
										.getPrimaryContactPerson());

						v9 = validation
								.recordStatusValidation(customerMasterTable
										.getRecordStatus());

						v10 = validation.flagValidation(customerMasterTable
								.getActiveInactiveFlag());
						v11 = validation
								.createDatevalidation(customerMasterTable
										.getCreateDate());
						v12 = validation.createByValidation(customerMasterTable
								.getCreatedBy());
						v13 = validation.modByvalidation(customerMasterTable
								.getModifiedBy());
						v14 = validation.authBYValidation(customerMasterTable
								.getAuthorizedBy());

						// ****************************FOR RECORD LEVEL
						// REJECTION**************************
						if (n == 1) {
							if (v1 && v2 && v3 && v4 && v5 && v6 && v7 && v8
									&& v9 && v10 && v11 && v12 && v13 && v14) {
								System.out.println(customerMasterTable);

								daoConnection.insertion(customerMasterTable);

							} else {

								bufferedWriter1.write(line);
								bufferedWriter1.newLine();
								bufferedWriter1.flush();
								if (!v1) {
									bufferedWriter1
											.write("ERROR in CUSTOMERCODE "
													+ customerMasterTable
															.getCustomerCode());
									bufferedWriter1.flush();

								}
								if (!v2) {
									bufferedWriter1
											.write("ERROR in CUSTOMERNAME "
													+ customerMasterTable
															.getCustomerName());
									bufferedWriter1.flush();

								}
								if (!v3) {
									bufferedWriter1.write("ERROR in Address "
											+ customerMasterTable
													.getCustomerAddress1());
									bufferedWriter1.flush();

								}
								if (!v4) {
									bufferedWriter1.write("ERROR in Address2 "
											+ customerMasterTable
													.getCustomerAddress2());
									bufferedWriter1.flush();
								}
								if (!v5) {
									bufferedWriter1.write("ERROR in PinCode "
											+ customerMasterTable
													.getCustomerPinCode());
									bufferedWriter1.flush();

								}
								if (!v6) {
									bufferedWriter1
											.write("ERROR in Email Address "
													+ customerMasterTable
															.getEmailAddress());
									bufferedWriter1.flush();

								}
								if (!v7) {
									bufferedWriter1
											.write("Error in contact number"
													+ customerMasterTable
															.getContactNumber());
									bufferedWriter1.flush();

								}
								if (!v8) {
									bufferedWriter1
											.write("Error in PrimaryContactPerson()"
													+ customerMasterTable
															.getPrimaryContactPerson());
									bufferedWriter1.flush();

								}
								if (!v9) {
									bufferedWriter1
											.write("Error in record status"
													+ customerMasterTable
															.getRecordStatus());
									bufferedWriter1.flush();

								}
								if (!v10) {
									bufferedWriter1.write("Error in flag"
											+ customerMasterTable
													.getActiveInactiveFlag());
									bufferedWriter1.flush();

								}
								if (!v11) {
									bufferedWriter1
											.write("Error in Creation Date"
													+ customerMasterTable
															.getCreateDate());
									bufferedWriter1.flush();

								}
								if (!v12) {
									bufferedWriter1
											.write("Error in Created by field"
													+ customerMasterTable
															.getCreatedBy());
									bufferedWriter1.flush();

								}
								if (!v13) {
									bufferedWriter1
											.write("Error in modified by field"
													+ customerMasterTable
															.getModifiedBy());
									bufferedWriter1.flush();

								}
								if (!v14) {
									bufferedWriter1
											.write("Error in Authorized by field"
													+ customerMasterTable
															.getAuthorizedBy());
									bufferedWriter1.flush();

								}
								bufferedWriter1.newLine();
								bufferedWriter1.flush();

							}

						}
						// ******************************* FOR FILE LEVEL
						// REJECTION***********************
						if (n == 2) {
							//
							if (v1 && v2 && v3 && v4 && v5 && v6 && v7 && v8
									&& v9 && v10 && v11 && v12 && v13 && v14
									&& flag == 0) {
								list.add(line);
								System.out.println(list);
								System.out.println(customerMasterTable);
								// *************************INSERTING ROLLBACKED
								// DATA INTO THE RECORD LOG*****************
								rollBack.saveToFile1(line);

								// daoConnection.insertion(customerMasterTable);
							} else {
								// THIS BUFFER WRITTER OBJECT WILL WRITE THE
								// ERROR LOGS AND ERROR FIELDS INTO THE ERROR
								// LOG FILE
								// bw1--> BufferWritter object to write in the
								// file
								bufferedReader2.write(line);
								bufferedReader2.newLine();// .newline()--> moves
															// to the next line
															// after one line
															// writing
								bufferedReader2.flush(); // it is used to save
															// the
								if (!v1) {
									bufferedReader2
											.write("ERROR in CUSTOMERCODE "
													+ customerMasterTable
															.getCustomerCode());
									bufferedReader2.flush();

								}
								if (!v2) {
									bufferedReader2
											.write("ERROR in CUSTOMERNAME "
													+ customerMasterTable
															.getCustomerName());
									bufferedReader2.flush();

								}
								if (!v3) {
									bufferedReader2.write("ERROR in Address "
											+ customerMasterTable
													.getCustomerAddress1());
									bufferedReader2.flush();

								}
								if (!v4) {
									bufferedReader2.write("ERROR in Address2 "
											+ customerMasterTable
													.getCustomerAddress2());
									bufferedReader2.flush();
								}
								if (!v5) {
									bufferedReader2.write("ERROR in PinCode "
											+ customerMasterTable
													.getCustomerPinCode());
									bufferedReader2.flush();

								}
								if (!v6) {
									bufferedReader2
											.write("ERROR in Email Address "
													+ customerMasterTable
															.getEmailAddress());
									bufferedReader2.flush();

								}
								if (!v7) {
									bufferedReader2
											.write("Error in contact number"
													+ customerMasterTable
															.getContactNumber());
									bufferedReader2.flush();

								}
								if (!v8) {
									bufferedReader2
											.write("Error in PrimaryContactPerson()"
													+ customerMasterTable
															.getPrimaryContactPerson());
									bufferedReader2.flush();

								}
								if (!v9) {
									bufferedReader2
											.write("Error in record status"
													+ customerMasterTable
															.getRecordStatus());
									bufferedReader2.flush();

								}
								if (!v10) {
									bufferedReader2.write("Error in flag"
											+ customerMasterTable
													.getActiveInactiveFlag());
									bufferedReader2.flush();

								}
								if (!v11) {
									bufferedReader2
											.write("Error in Creation Date"
													+ customerMasterTable
															.getCreateDate());
									bufferedReader2.flush();

								}
								if (!v12) {
									bufferedReader2
											.write("Error in Created by field"
													+ customerMasterTable
															.getCreatedBy());
									bufferedReader2.flush();

								}
								if (!v13) {
									bufferedReader2
											.write("Error in modified by field"
													+ customerMasterTable
															.getModifiedBy());
									bufferedReader2.flush();

								}
								if (!v14) {
									bufferedReader2
											.write("Error in Authorized by field"
													+ customerMasterTable
															.getAuthorizedBy());
									bufferedReader2.flush();

								}
								bufferedReader2.newLine();
								bufferedReader2.flush();
								flag++;

								break;

							}

						}

					}
					bufferedReader.close();
					bufferedWriter1.close();
					bufferedReader2.close();

					// THIS SECTION OF CODE WILL EXECUTE in FILE MODE WHEN ALL
					// THE
					// RECORDS IN THE LIST IS VALID
					if (flag == 0) {
						SplitSring splitSring = new SplitSring();
						for (int i = 0; i < list.size(); i++) {
							splitSring.split(list.get(i));
							System.out.println(list.get(i));
						}
					}

				} catch (NumberFormatException e) {

					e.printStackTrace();
				} catch (IOException e) {

					e.printStackTrace();
				}

			} catch (FileNotFoundException e) {

				System.out
						.println("File Loading Error...............File not found.........");
			}

		} else {
			System.out
					.println("File Loading Error...............File not found.........");
		}

	}
}
