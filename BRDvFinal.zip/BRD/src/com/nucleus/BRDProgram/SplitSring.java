package com.nucleus.BRDProgram;

public class SplitSring {
	public void split(String line){
		CustomerMasterTable cmt= new CustomerMasterTable();
		DaoConnection daoConnection=new DaoConnection();
		String str[]=line.split("~",-1);
		cmt.setCustomerCode(str[0]);
		cmt.setCustomerName(str[1]);
		cmt.setCustomerAddress1(str[2]);
		cmt.setCustomerAddress2(str[3]);
		cmt.setCustomerPinCode(str[4]);
		cmt.setEmailAddress(str[5]);
		cmt.setContactNumber(str[6]);
		cmt.setPrimaryContactPerson(str[7]);
		cmt.setRecordStatus(str[8]);
		cmt.setActiveInactiveFlag(str[9]);
		cmt.setCreateDate(str[10]);
		cmt.setCreatedBy(str[11]);
		cmt.setModifiedDate(str[12]);
		cmt.setModifiedBy(str[13]);
		cmt.setAuthorizedDate(str[14]);
		cmt.setAuthorizedBy(str[15]);
		daoConnection.insertion(cmt);
		
	}

}
